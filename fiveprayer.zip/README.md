=== Five Prayer ===
Contributors: jamaaldev
Tags: prayer,muslim,fiveprayer
Donate link: https://www.buymeacoffee.com/jamaaldev
Requires at least: 5.9
Tested up to: 6.0.3
Requires PHP: 5.6
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.txt

Five Prayer is Muslim PrayerTimes.

== Description ==
Five Prayer Plugin is For Muslim WordPress Website

Who Can Benefit From Five Prayer? 

Five Prayer Plugin is perfect for:
1. Muslim Masjid or Muslim Mosque
2. Community Masjid
3. Any WP Website Wants To show PrayerTime

* Many More Features are Coming in Future

* ShortCode.
 - `[Fp_TimeTable_Monthly]`   Displaying Monthly Timetable Prayer 
 - `[Fp_Vertical_Daily_Prayer]`   Displaying Today Timetable Prayer Vertically


== Installation ==
1. Visit `Plugins > Add New`
2. Search for Five Prayer`
3. Install Five Prayer once it appears
4. Activate Five Prayer from your Plugins page.
5. Go to \"after activation\" below.

= Manually =

1. Upload the `Five Prayer` folder to the `/wp-content/plugins/` directory
2. Activate the Five Prayer plugin through the \'Plugins\' menu in WordPress
3. Go to \"after activation\" below.

= After activation =

1. You should see the Five Prayer at the sidebar admin.
2. You\'re done!


== Frequently Asked Questions ==
= how can we request a feature =
I am very sorry at the moment I am working alone and still need to finish more tasks, inshallah one day I will open a feature request section  

== Screenshots ==
1. Importand Go to Setting - General - Timezone Change Your Timezone
2. FivePrayer go to More Settings - Prayer Configration - click Customlocation add the details
3. FivePrayer go to Prayer Settings Fill Everything and Press Generate Calendar

== Changelog ==
= 1.0.0 =
* First release.
* Feature ShortCode Monthly Calendar with Printer Option.
* Feature ShortCode Daily Prayer Times.

== Upgrade Notice ==
= 1.0.0 =
* First release.